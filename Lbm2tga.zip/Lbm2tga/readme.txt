LBM2TGA -- Next-Generation Bidirectional IFF-LBM <-> TGA Converter
-- dEsign & c0de by: EMX / PhRoZeNCReW (1997) - ISTANBUL 2026 
Usage: LBM2TGA.exe <input.lbm|input.tga> [options]

  LBM -> TGA :  LBM2TGA picture.lbm
                LBM2TGA picture.lbm -o out.tga
  TGA -> LBM :  LBM2TGA picture.tga
                LBM2TGA picture.tga -o out.lbm

Options:
  -o <file>       explicit output filename
  -t              force LBM -> TGA (decode) direction
  -l              force TGA -> LBM (encode) direction
  -y, --yes       assume default answers to all interactive prompts
  --rle           force RLE compression on the output file
  --no-rle        force uncompressed (raw) output
  --8bit          write an 8-bit indexed TGA    (LBM -> TGA only)
  --16bit         write a 16-bit (5-5-5) TGA    (LBM -> TGA only)
  --24bit         write a 24-bit truecolor TGA  (LBM -> TGA only)
  --32bit         write a 32-bit RGBA TGA       (LBM -> TGA only)
  --colors <n>    max palette size when quantizing, 2-256 (TGA -> LBM only)
  --mask          keep a transparency mask plane in the LBM output
  --no-mask       discard transparency when writing the LBM output
  --threads <n>   worker thread count (default: all logical CPUs)
  -h, --help      show this help text

Supported LBM : FORM ILBM (planar) and FORM PBM (chunky), 1-8 bitplanes,
                ByteRun1 RLE or raw, masking 0/1/2.
Supported TGA : 8-bit colormapped or grayscale, 15/16/24/32-bit truecolor,
                RLE (types 9/10/11) or raw (types 1/2/3), any origin corner.
